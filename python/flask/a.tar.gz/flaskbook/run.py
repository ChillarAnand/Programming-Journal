#! /home/anand/git/learning/python/flask/flask/bin/python

from app import app
app.run(debug = True)
